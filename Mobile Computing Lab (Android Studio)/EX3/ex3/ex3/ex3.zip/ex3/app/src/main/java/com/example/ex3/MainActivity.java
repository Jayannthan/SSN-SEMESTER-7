package com.example.ex3;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    private RelativeLayout carLayout;
    private Button moveButton;
    private Button moveBack;
    private int currentPosition = 0;
    private boolean isFlipped = false;// Current position of the car
    private boolean isZoomed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        carLayout = findViewById(R.id.carLayout); // Use the ID of the RelativeLayout
        moveButton = findViewById(R.id.moveForwardButton);
        moveBack = findViewById(R.id.moveBackButton);

        moveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveCar();
            }
        });

        moveBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveCarBackward();
            }
        });


        carLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isZoomed) {
                    // If already zoomed, zoom out to original size
                    zoomOut();
                } else {
                    // If not zoomed, zoom in
                    zoomIn();
                }
            }
        });
    }


    private void zoomIn() {
        // Scale the layout and its contents
        carLayout.setScaleX(1.5f); // 1.5 times scaling on the X-axis
        carLayout.setScaleY(1.5f); // 1.5 times scaling on the Y-axis
        isZoomed = true;
    }

    private void zoomOut() {
        // Reset the scale to normal (1x)
        carLayout.setScaleX(1f);
        carLayout.setScaleY(1f);
        isZoomed = false;
    }

    private void moveCar() {
        int start = currentPosition;
        int end = start + 100; // Adjust the distance as needed
//        int rotation = 0;
//        // Create ObjectAnimators for translation and rotation
//        ObjectAnimator translationXAnimator = ObjectAnimator.ofFloat(carLayout, "translationX", start, end);
//        ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(carLayout, "rotationY", rotation, 0);
//
//        // Create an AnimatorSet to run both animations together
//        AnimatorSet animatorSet = new AnimatorSet();
//        animatorSet.playTogether(translationXAnimator, rotationAnimator);
//        animatorSet.setDuration(1000); // Animation duration in milliseconds (1 second in this example)
//        animatorSet.start();
//
//        // Update the current position of the car
//        currentPosition = end;
//        isFlipped = false;

        // Create an ObjectAnimator to move the car layout
        ObjectAnimator animator;
        if (isFlipped==false){
        animator = ObjectAnimator.ofFloat(carLayout, "translationX", start, end);}
        else {
            animator = ObjectAnimator.ofFloat(carLayout, "translationX",  end,start);
        }
        animator.setDuration(1000); // Animation duration in milliseconds (1 second in this example)
        animator.start();

        // Update the current position of the car
        currentPosition = end;
    }


    private void moveCarBackward() {
        int start = currentPosition;
        int end = start - 100; // Adjust the distance as needed
        ObjectAnimator rotationAnimator;
        int rotation;
        if (isFlipped==true){
            rotation=180;
            rotationAnimator = ObjectAnimator.ofFloat(carLayout, "rotationY", rotation, 0);
            isFlipped=false;
        }
        else {
            rotation=0;
            rotationAnimator = ObjectAnimator.ofFloat(carLayout, "rotationY", rotation, 180);
            isFlipped=true;
        }


        rotationAnimator.setDuration(1000); // Animation duration in milliseconds (1 second in this example)
        rotationAnimator.start();

        // Update the current position of the car
        currentPosition = end;
    }
}








