package com.example.threads;

import android.animation.ObjectAnimator;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private Thread colorChangingThread;
    private Thread movingBannerThread;
    private Thread counterThread;
    private boolean isThreadsRunning = false;

    private Button start, stop, resume;
    private ImageView movingImageView;
    private ObjectAnimator animator;
    private final Handler colorHandler = new Handler(Looper.getMainLooper());
    private final Handler bannerHandler = new Handler(Looper.getMainLooper());
    private final Handler counterHandler = new Handler(Looper.getMainLooper());
    private int colorIndex = 0, counter = 0;
    private String bannerText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons after setContentView
        start = findViewById(R.id.start);
        stop = findViewById(R.id.stop);
        resume = findViewById(R.id.resume);
        movingImageView = findViewById(R.id.movingBanner);

        animator = ObjectAnimator.ofFloat(movingImageView, "translationX", -100, 900);
        animator.setDuration(2000);
        animator.setRepeatCount(ObjectAnimator.INFINITE);

        // Set OnClickListener for the Start button
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restartThreads(view);
            }
        });

        // Set OnClickListener for the Stop button
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopThreads(view);
            }
        });

        // Set OnClickListener for the Resume button
        resume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resumeThreads(view);
            }
        });
    }

    public void restartThreads(View view) {
        // Stop threads if they are running
        stopThreads(view);

        // Reset state variables to their initial values
        colorIndex = 0;
        bannerText = "This is a moving banner.... ";
        counter = 999;
        animator.start();

        // Start threads with reset state
        startThreads(view);
    }

    public void startThreads(View view) {
        if (!isThreadsRunning) {
            isThreadsRunning = true;

            colorChangingThread = new Thread(() -> {
                while (isThreadsRunning) {
                    colorHandler.post(() -> updateColor());
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            colorChangingThread.start();

            movingBannerThread = new Thread(() -> {
                while (isThreadsRunning) {
                    bannerHandler.post(() -> updateBanner());
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            movingBannerThread.start();

            counterThread = new Thread(() -> {
                while (isThreadsRunning) {
                    counterHandler.post(() -> updateCounter());
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            counterThread.start();
        }
    }

    public void stopThreads(View view) {
        isThreadsRunning = false;
        animator.pause();
    }

    public void resumeThreads(View view) {
        startThreads(view);
    }

    private void updateColor() {
        String[] colors = {
                "#FF0000", // Red
                "#FF4000", // Red-Orange
                "#FF8000", // Orange
                "#FFBF00", // Orange-Yellow
                "#FFFF00", // Yellow
                "#BFFF00", // Yellow-Green
                "#80FF00", // Green
                "#40FF00", // Green-Aqua
                "#00FF00", // Aqua
                "#00FF40", // Aqua-Green
                "#00FF80", // Aqua-Blue
                "#00FFBF", // Aqua-Blue (Light)
                "#00FFFF", // Cyan
                "#00BFFF", // Light Blue
                "#0080FF", // Sky Blue
                "#0040FF", // Blue
                "#0000FF", // Dark Blue
                "#4000FF", // Blue-Purple
                "#8000FF", // Purple
                "#BF00FF", // Purple-Pink
                "#FF00FF"  // Pink
        };
        TextView colorTextView = findViewById(R.id.colorShift);
        colorTextView.setTextColor(Color.parseColor(colors[colorIndex]));
        colorIndex = (colorIndex + 1) % colors.length;
    }

    private void updateBanner() {
        TextView bannerTextView = findViewById(R.id.banner);
        bannerTextView.setText(bannerText);
        bannerText = bannerText.charAt(bannerText.length() - 1) + bannerText.substring(0, bannerText.length() - 1);
        animator.resume();
    }


    private void updateCounter() {
        TextView counterTextView = findViewById(R.id.counter);
        if(counter == 1000)
            counter = 0;
        counterTextView.setText(String.valueOf(counter));
        counter++;
    }

}