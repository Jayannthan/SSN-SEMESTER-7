package com.example.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
	// Request code for sending SMS permission
	private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

	// UI elements
	private Button sendBtn;
	private EditText txtPhoneNo;
	private EditText txtMessage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Check if RECEIVE_SMS permission is granted
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {
			// Display a message if permission is granted
			Toast.makeText(this, "Received SMS permission granted", Toast.LENGTH_SHORT).show();
		} else {
			// If not granted, request RECEIVE_SMS permission
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, 100);
		}

		// Initialize UI elements
		sendBtn = findViewById(R.id.sendbtn);
		txtPhoneNo = findViewById(R.id.etPhone);
		txtMessage = findViewById(R.id.content);

		// Set click listener for the send button
		sendBtn.setOnClickListener(view -> sendSMSMessage());
	}

	// Method to initiate sending an SMS
	private void sendSMSMessage() {
		// Retrieve phone number and message from UI
		String phoneNo = txtPhoneNo.getText().toString();
		String message = txtMessage.getText().toString();

		// Check if the app has the SEND_SMS permission
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
				!= PackageManager.PERMISSION_GRANTED) {
			// If not, request the permission
			requestSmsPermission();
		} else {
			// If permission is granted, proceed to send the SMS
			sendSms(phoneNo, message);
		}
	}

	// Method to request SEND_SMS permission
	private void requestSmsPermission() {
		ActivityCompat.requestPermissions(
				this,
				new String[]{Manifest.permission.SEND_SMS},
				MY_PERMISSIONS_REQUEST_SEND_SMS
		);
	}

	// Method to send an SMS
	private void sendSms(String phoneNo, String message) {
		// Use SmsManager to send the SMS
		SmsManager smsManager = SmsManager.getDefault();
		smsManager.sendTextMessage(phoneNo, null, message, null, null);

		// Display a Toast message indicating that the SMS was sent
		showToast("SMS sent.");
	}

	// Callback for handling permission request results
	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);

		// Check if the permission request is for SEND_SMS
		if (requestCode == MY_PERMISSIONS_REQUEST_SEND_SMS) {
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
				// If permission is granted, proceed to send the SMS
				sendSMSMessage();
			} else {
				// If permission is denied, display a Toast message
				showToast("SMS permission denied. Cannot send SMS.");
			}
		}

		// Check if the permission request is for RECEIVE_SMS
		if (requestCode == 100) {
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
				// Permission granted, perform necessary actions
				Toast.makeText(this, "Received SMS permission granted", Toast.LENGTH_SHORT).show();
			} else {
				// Permission denied, inform the user
				Toast.makeText(this, "Received SMS permission denied", Toast.LENGTH_SHORT).show();
			}
		}
	}

	// Method to display a Toast message
	private void showToast(String message) {
		Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
	}
}
