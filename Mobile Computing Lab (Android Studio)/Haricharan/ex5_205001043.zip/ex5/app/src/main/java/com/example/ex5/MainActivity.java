package com.example.ex5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView displayTextView;
    private TextView displayTimer;
    private Button startButton;
    private Button stopButton;
    private Button resumeButton;

    private boolean isRunning = true;
    private boolean isPaused = false;
    private int counter = 0;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayTextView = findViewById(R.id.text);
        displayTimer = findViewById(R.id.time);
        startButton = findViewById(R.id.start);
        stopButton = findViewById(R.id.stop);
        resumeButton = findViewById(R.id.resume);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startButton.setEnabled(false);
                stopButton.setVisibility(View.VISIBLE);
                startThreads();
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isRunning = false;
                startButton.setEnabled(false);
                stopButton.setVisibility(View.GONE);
                resumeButton.setVisibility(View.VISIBLE);
            }
        });

        resumeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isRunning = true;
                isPaused = false;
                resumeButton.setVisibility(View.GONE);
                stopButton.setVisibility(View.VISIBLE);
                startThreads();
            }
        });
    }

    private void startThreads() {
        isPaused = false;

        // Thread 1: Change text color indefinitely
        Thread colorThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isPaused) {
                                displayTextView.setTextColor(getRandomColor());
                            }
                        }
                    });
                }
            }
        });

        // Thread 2: Implement a moving banner
        Thread bannerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isPaused) {
                                ImageView v=findViewById(R.id.banner);
                                float currentX = v.getTranslationX();
                                v.setTranslationX(currentX+5);
                            }
                        }
                    });
                }
            }
        });

        // Thread 3: Display a counter from 0 to 1000
        Thread counterThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning && counter <= 1000) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isPaused) {
                                displayTimer.setText(String.valueOf(counter));
                                counter++;
                            }
                        }
                    });
                }
            }
        });

        colorThread.start();
        bannerThread.start();
        counterThread.start();
    }

    private int getRandomColor() {
        int r = (int) (Math.random() * 256);
        int g = (int) (Math.random() * 256);
        int b = (int) (Math.random() * 256);
        return 0xff000000 | (r << 16) | (g << 8) | b;
    }
}
