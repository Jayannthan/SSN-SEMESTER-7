package com.example.ex4;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


public class DBHandler extends SQLiteOpenHelper {


    public DBHandler(Context context) {
        super(context, "product_db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE Products  ( pid INTEGER PRIMARY KEY AUTOINCREMENT, pname TEXT,"
                + "pbrand TEXT,pdesc TEXT,pprice INTEGER)";
        db.execSQL(query);
    }


    public void addNewProduct(String pid,String pname,String pbrand,String pd,String pp) {
        SQLiteDatabase db = this.getWritableDatabase();


        ContentValues values = new ContentValues();


        values.put("pid", pid);
        values.put("pname", pname);
        values.put("pbrand", pbrand);
        values.put("pdesc", pd);
        values.put("pprice", pp);


        long result=db.insert("Products", null, values);
        db.close();
    }


    public void updateData(String pid,String price){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("Update Products set pprice="+"'"+price+"'"+" where pid="+pid);
    }


    public void delData(String pid){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("Delete from Products "+" where pid="+pid);
    }


    public Cursor getData(String pid){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+"Products"+" where pid="+pid,null);
        return res;
    }


    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+"Products",null);
        return res;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + "Products");
        onCreate(db);
    }
}
