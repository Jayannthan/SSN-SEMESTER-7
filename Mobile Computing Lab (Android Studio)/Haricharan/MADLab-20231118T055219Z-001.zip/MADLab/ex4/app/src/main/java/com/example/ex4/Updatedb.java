package com.example.ex4;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Updatedb extends AppCompatActivity implements View.OnClickListener {


    Button btn;
    EditText pid,price;
    DBHandler dbhandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update);


        btn=findViewById(R.id.ubtn);
        pid=findViewById(R.id.etpidup);
        price=findViewById(R.id.uppri);


        dbhandler = new DBHandler(Updatedb.this);


        btn.setOnClickListener(this);
    }
    public void onClick(View v){
        String pidv=pid.getText().toString();
        String ppv=price.getText().toString();
        dbhandler.updateData(pidv,ppv);
        Toast.makeText(Updatedb.this,"Updated!", Toast.LENGTH_SHORT).show();
    }


}
