package com.example.ex4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;


public class Deletedb extends AppCompatActivity implements View.OnClickListener {


    Button btn;
    EditText pid;
    DBHandler dbhandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete);


        btn=findViewById(R.id.delbtn);
        pid=findViewById(R.id.dpid);


        dbhandler = new DBHandler(Deletedb.this);


        btn.setOnClickListener(this);
    }


    public void onClick(View v){
        String pidv=pid.getText().toString();
        dbhandler.delData(pidv);
        Toast.makeText(Deletedb.this,"Deleted!", Toast.LENGTH_SHORT).show();
    }


}

