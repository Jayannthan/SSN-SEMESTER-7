package com.example.ex4;
import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Button insert;
    Button update;
    Button del;
    Button ret;
    Button viewa;
    private DBHandler dbhandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        insert=findViewById(R.id.insbtn);
        update=findViewById(R.id.updbtn);
        del=findViewById(R.id.delbtn);
        ret=findViewById(R.id.retbtn);
        viewa=findViewById(R.id.viewbtn);
        insert.setOnClickListener(this);
        update.setOnClickListener(this);
        del.setOnClickListener(this);
        ret.setOnClickListener(this);
        viewa.setOnClickListener(this);


    }
    @Override
    public void onClick(View v) {
        String ans="";
        if(v.getId()==R.id.insbtn){
            Intent i = new Intent(MainActivity.this,Insertdb.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.updbtn){
            Intent i = new Intent(MainActivity.this,Updatedb.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.delbtn){
            Intent i = new Intent(MainActivity.this,Deletedb.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.retbtn){
            Intent i = new Intent(MainActivity.this,Viewdb.class);
            startActivity(i);
        }
        else{
            dbhandler = new DBHandler(MainActivity.this);
            Cursor res=dbhandler.getAllData();
            if(res.getCount()==0){
                ans="No Data";
            }
            else{
                while (res.moveToNext()){
                    ans+="PID: "+ res.getString(0)+"\n";
                    ans+="Name: "+ res.getString(1)+"\n";
                    ans+="Brand: "+ res.getString(2)+"\n";
                    ans+="Price: "+ res.getString(4)+"\n";
                    ans+="Description: "+ res.getString(3)+"\n\n";
                }
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setMessage(ans);
            builder.show();
        }
    }
}
