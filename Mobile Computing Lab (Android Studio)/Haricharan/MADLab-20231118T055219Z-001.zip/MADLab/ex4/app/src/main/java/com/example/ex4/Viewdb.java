package com.example.ex4;

import androidx.appcompat.app.AppCompatActivity;


import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Viewdb extends AppCompatActivity implements View.OnClickListener {


    Button btn;
    EditText et;
    DBHandler dbhandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view);
        btn=findViewById(R.id.sbtn);
        btn.setOnClickListener(this);
        et=findViewById(R.id.pidser);
    }
    public void onClick(View v){
        dbhandler = new DBHandler(Viewdb.this);
        String ser=et.getText().toString();
        Cursor res=dbhandler.getData(ser);
        String ans="";
        if(res.getCount()==0){
            ans="No Data";
        }
        else{
            while (res.moveToNext()){
                ans+="PID: "+ res.getString(0)+"\n";
                ans+="Name: "+ res.getString(1)+"\n";
                ans+="Brand: "+ res.getString(2)+"\n";
                ans+="Price: "+ res.getString(4)+"\n";
                ans+="Description: "+ res.getString(3)+"\n\n";
            }
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setMessage(ans);
        builder.show();
    }


}
