package com.example.ex4;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;


public class Insertdb extends AppCompatActivity implements View.OnClickListener {
    private DBHandler dbhandler;
    EditText pid,pd,pp;
    RadioButton pb1,pb2;
    Button btn;
    Spinner sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.insert);
        sp=findViewById(R.id.pname);
        ArrayAdapter<CharSequence> adp=ArrayAdapter.createFromResource(this,R.array.arr,android.R.layout.simple_spinner_item);
        adp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adp);


        pid=findViewById(R.id.pidet);
        pd=findViewById(R.id.pdesc);
        pp=findViewById(R.id.ppri);
        pb1=findViewById(R.id.pb_1);


        dbhandler = new DBHandler(Insertdb.this);




        btn=findViewById(R.id.insbtn);
        btn.setOnClickListener(this);




    }
    public void onClick(View v){
        String pidv=pid.getText().toString();
        String pdv=pd.getText().toString();
        String ppv=pp.getText().toString();
        String pbv;
        if(pb1.isChecked())
            pbv="Apple";
        else
            pbv="Mango";
        String pnamev=sp.getSelectedItem().toString();
        if(pidv.matches("^[0-9]{4}$") && pdv.matches("^[a-zA-Z0-9]*$") && ppv.matches("^[0-9]*$")) {
            dbhandler.addNewProduct(pidv, pnamev, pbv, pdv, ppv);
            Toast.makeText(Insertdb.this, "Inserted!", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(Insertdb.this, "Enter valid values", Toast.LENGTH_SHORT).show();
        }
    }


}

